naam = input('Hallo, wat is je naam? ')
leeftijd=input(f'goedendag {naam}, hoe oud ben je? ')
eten = input(f'en als {leeftijd} jarige, waat eet je het liefst? ' )
drinken = input(f'en wat drink je het liefst bij {eten} ')

print(f'De {leeftijd} jarige {naam} drinkt het liefst {drinken} bij {eten}')
